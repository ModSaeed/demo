# -*- coding: utf-8 -*-

from . import dashboard_portal
