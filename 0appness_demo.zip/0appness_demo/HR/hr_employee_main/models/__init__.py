# -*- coding: utf-8 -*-

from . import models
from . import hr_employee
from . import hr_employee_custody
from . import hr_employee_dependent
from . import hr_employee_training_history