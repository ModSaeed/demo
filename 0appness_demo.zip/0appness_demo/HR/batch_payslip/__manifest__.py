# -*- coding: utf-8 -*-

{
    'name': 'Appness HR: Batch payslip generation',
    'summary': """Empty list of employee when generate the payslip.""",
    'description': """Empty list of employee when generate the payslip.""",
    'category': 'HR',
    'version': '14.0.1',
    'sequence': 50,
    'author': 'Appness Technology',
    'maintainer': 'Appness Technology',
    'company': 'Appness Technology',
    'website': 'https://www.appness.net',
    'depends': ['base', 'hr', 'hr_payroll',],
    'data': [],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}