from odoo import fields , api , models , _
import datetime
from dateutil.relativedelta import relativedelta
from openerp.exceptions import except_orm, Warning, RedirectWarning, UserError

class employee_promotion(models.Model):
	_name = 'employee.promotion'
	_description = 'Employee Promotion'
	_rec_name = 'employee_id'
	_inherit = ['mail.thread','mail.activity.mixin']

	@api.constrains('grade_id','n_grade_id')
	def _check_sequence(self):
		if self.grade_id and self.n_grade_id and (self.n_grade_id.sequence > self.grade_id.sequence):
			raise UserError('New Grade Sequence Is Less Than Current Grade Sequence')

	name = fields.Char('Reference')
	date = fields.Date("Date", default=datetime.datetime.now().date(), readonly=True)
	employee_id = fields.Many2one("hr.employee", "Employee", required=True)
	department_id = fields.Many2one("hr.department","Department", readonly=True, compute="_onchange_employee_id",store=True)
	job_id = fields.Many2one("hr.job", "Job Title", readonly=True,compute="_onchange_employee_id",store=True)
	n_department_id = fields.Many2one("hr.department", "New Department",)
	n_job_id = fields.Many2one("hr.job", "New Job Title")
	state = fields.Selection([
		('draft','Draft'),
		('hr_manager_approve','Waiting Hr Manager Approval'),
		('approve', 'Approved'),
		('reject', 'rejected'),
	], default='draft',track_visibility='onchnage')
	company_id = fields.Many2one("res.company", string="Company", related="employee_id.company_id", store=True,readonly=True)
	note = fields.Text("Note")
	grade_id = fields.Many2one('hr.grade.configuration','Grade', compute="_onchange_employee_id",store=True)
	n_grade_id = fields.Many2one('hr.grade.configuration','New Grade')
	grade_promotion = fields.Boolean('Grade Promotion')
	include_department_rotation = fields.Boolean('Department Rotation')
	include_job_rotation = fields.Boolean('Job Rotation')
	
	basic = fields.Float("Basic",compute="_onchange_employee_id",store=True)
	total_allowances = fields.Float("Total Allowances",compute="_onchange_employee_id",store=True)
	# cost_living = fields.Float("Cost Of Living",compute="_onchange_employee_id",store=True)
	# petrol_allowance = fields.Float("Petrol Allowance",compute="_onchange_employee_id",store=True)
	other_allowance = fields.Float("Other Allowances",compute="_onchange_employee_id",store=True)
	transportation = fields.Float(string='Transportation',compute="_onchange_employee_id",store=True)
	housing = fields.Float(string='Housing',compute="_onchange_employee_id",store=True)
	utilities_allow = fields.Float(string='Utilities Allowance',compute="_onchange_employee_id",store=True)
	# telephone = fields.Float("Telephone",compute="_onchange_employee_id",store=True)
	wage = fields.Float("Gross",compute="_onchange_employee_id",store=True)

	new_basic = fields.Float("New Basic")
	new_total_allowances = fields.Float("New Total Allowances",)
	# new_cost_living = fields.Float("New Cost Of Living")
	# new_petrol_allowance = fields.Float("New Petrol Allowance")
	new_other_allowance = fields.Float("New Other Allowances")
	new_transportation = fields.Float(string='New Transportation')
	new_housing = fields.Float(string='New Housing')
	new_utilities_allow = fields.Float(string='New Utilities Allowance')
	# new_telephone = fields.Float("New Telephone")
	new_wage = fields.Float("New Gross",compute="_new_wage",store=True)

	is_salary_promotion = fields.Boolean('Salary Promotion')
	rotation_ids = fields.One2many('employee.rotation','promotion_id')
	salary_increase_ids = fields.One2many('hr.salary.increase.line','promotion_id')

	@api.depends('new_basic','new_total_allowances','new_other_allowance','new_utilities_allow','new_transportation','new_housing')
	def _new_wage(self):
		self.new_wage = self.new_basic + self.new_other_allowance+ self.new_transportation + self.new_housing + self.new_utilities_allow

	def update_activities(self):
		for rec in self:
			users =[]
			rec.activity_unlink(['hr_employee_promotion.mail_act_approval'])
			if rec.state not in ['draft', 'hr_manager_approve','approve', 'reject']:
				continue
			message = ""
			if rec.state == 'hr_manager_approve':
				users = self.env.ref('hr.group_hr_manager').users
				message = "Approve"
			elif rec.state == 'reject':
				users = [self.create_uid]
				message = "Cancelled"
			for user in users:
				self.activity_schedule('hr_employee_promotion.mail_act_approval', user_id=user.id, note=message)


	@api.depends('employee_id')
	def _onchange_employee_id(self):
		for rec in self:
			rec.department_id = rec.employee_id.department_id
			rec.job_id = rec.employee_id.job_id
			rec.grade_id = rec.employee_id.contract_id.grade_id or False
			rec.basic = rec.employee_id.contract_id.basic
			rec.total_allowances = rec.employee_id.contract_id.total_allowances
			# rec.cost_living = rec.employee_id.contract_id.cost_living
			# rec.petrol_allowance = rec.employee_id.contract_id.petrol_allowance
			rec.other_allowance = rec.employee_id.contract_id.other_allowance
			rec.transportation = rec.employee_id.contract_id.transportation
			rec.housing = rec.employee_id.contract_id.housing
			rec.utilities_allow = rec.employee_id.contract_id.utilities_allow
			# rec.telephone = rec.employee_id.contract_id.telephone
			rec.wage = rec.employee_id.contract_id.wage

	def unlink(self):
		for rec in self:
			if rec.state != 'draft':
				raise UserError("Only draft records can be deleted!")
		super(employee_promotion, self).unlink()

	@api.depends('n_grade_id')
	@api.onchange('n_grade_id')
	def _onchange_n_grade_id(self):
		for rec in self:
			rec.new_basic =  rec.n_grade_id.basic
			rec.new_total_allowances =  rec.n_grade_id.total_allowances
			# rec.new_cost_living =  rec.n_grade_id.cost_living
			# rec.new_petrol_allowance =  rec.n_grade_id.petrol_allowance
			rec.new_other_allowance = rec.n_grade_id.other_allowance
			rec.new_transportation =  rec.n_grade_id.transportation
			rec.new_housing = rec.n_grade_id.housing
			rec.new_utilities_allow = rec.n_grade_id.utilities_allow
			# rec.new_telephone =  (rec.n_grade_id.telephone/100) * rec.n_grade_id.total_allowances
			

	def submit(self):
		for rec in self:
			rec.state = 'hr_manager_approve'
			rec.update_activities()

	def hr_manager_approve(self):
		for rec in self:
			rec.sudo().action_approve()
			rec.state ="approve"
			rec.activity_unlink(['hr_employee_promotion.mail_act_approval'])
	
	def action_reset_draft(self):
		for rec in self:
			rec.state = 'draft'

	def create_employee_rotation(self):
		rotation = self.env['employee.rotation'] 
		for rec in self:
			employee_id = rec.employee_id.id or False
			department_id = rec.department_id
			n_department_id = rec.n_department_id
			job_id = rec.job_id.id or False
			n_job_id = rec.n_job_id.id or False
			vals = {
				'promotion_id':rec.id,
				'employee_id':employee_id,
				'date': datetime.datetime.today(),
				'department_id':department_id.id or False,
				'n_department_id':n_department_id.id or False,
				'job_id':job_id,
				'n_job_id':n_job_id,
				'state':'approve'
				}	
			current_item = [rec.department_id,rec.job_id]
			new_item = [rec.n_department_id,rec.n_job_id]

			if not all(item in current_item for item in new_item):
				rotation.create(vals)
			return

	def create_salary_increase(self):
		increase = self.env['hr.salary.increase']
		increase_line = self.env['hr.salary.increase.line']
		for rec in self:
			employee_id = rec.employee_id.id or False
			vals = {
					'date': datetime.datetime.now(),
					'date_applied_on':datetime.datetime.now(),
					'state':'confirm',
					'name': 'Promotion Salary for' +' '+ rec.employee_id.name,
					'increase_type':'promotion',
					'applied_for':'employee',
					}

			current_item = [rec.wage]
			new_item = [rec.new_wage]
			if not all(item in current_item for item in new_item):
				increase_id = increase.create(vals)
				if not increase_id:
					return
				vals_line = {
					'increase_id':increase_id.id,
					'promotion_id':rec.id,
					'employee_id':employee_id,
					'wage' : rec.wage,
					'new_wage':rec.new_wage,
					'amount':rec.new_wage - rec.wage,
				}		
				increase_line.create(vals_line)
			return

	def action_approve(self):
		for rec in self:
			if rec.n_department_id and rec.department_id != rec.n_department_id:
				rec.employee_id.department_id = rec.n_department_id
				rec.employee_id.contract_id.department_id = rec.n_department_id
			if rec.n_job_id and rec.job_id != rec.n_job_id:
				rec.employee_id.job_id = rec.n_job_id
				rec.employee_id.contract_id.job_id = rec.n_job_id
			if rec.n_grade_id and rec.grade_id != rec.n_grade_id:
				# rec.employee_id.grade_id = rec.n_grade_id
				rec.employee_id.contract_id.grade_id = rec.n_grade_id
			if rec.is_salary_promotion == True:
				# rec.employee_id.contract_id.check_constrains = False
				rec.employee_id.contract_id.basic = rec.new_basic
				rec.employee_id.contract_id.total_allowances = rec.new_total_allowances
				# rec.employee_id.contract_id.cost_living = rec.new_cost_living
				# rec.employee_id.contract_id.petrol_allowance = rec.new_petrol_allowance
				rec.employee_id.contract_id.other_allowance = rec.new_other_allowance
				rec.employee_id.contract_id.transportation = rec.new_transportation
				rec.employee_id.contract_id.housing = rec.new_housing
				rec.employee_id.contract_id.utilities_allow = rec.new_utilities_allow
				# rec.employee_id.contract_id.telephone = rec.new_telephone
				rec.employee_id.contract_id.update_gross()
			rec.state = 'approve'
			if rec.n_department_id :
				self.sudo().create_employee_rotation()
			if rec.is_salary_promotion == True:
				self.sudo().create_salary_increase()

	def action_reject(self):
		self.state ="reject"
		self.update_activities()



class EmployeeRotation(models.Model):
	_inherit = 'employee.rotation'

	promotion_id = fields.Many2one('employee.promotion','Promotion')

class SalaryIncreaseLine(models.Model):
	_inherit = 'hr.salary.increase.line'

	promotion_id = fields.Many2one('employee.promotion','Promotion')


class hrEmployee(models.Model):
    _inherit = 'hr.employee'

    def compute_promotion_count(self):
        for record in self:
            record.promotion_count = self.env['employee.promotion'].search_count(
                [('employee_id', '=', self.id)])

    promotion_count = fields.Integer(compute='compute_promotion_count')

    def get_promotion(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Promotion',
            'view_mode': 'tree',
            'res_model': 'employee.promotion',
            'domain': [('employee_id', '=', self.id)],
            'context': "{'create': False}"
        }
