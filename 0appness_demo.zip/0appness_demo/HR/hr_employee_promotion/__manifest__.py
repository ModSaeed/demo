# -*- coding: utf-8 -*-
{
    'name': "Appness HR : Employee Promotion",
    'summary': """Employee Promotion """,
    'description': """Employee Promotion""",
    'author': "Appness Technology",
    'website': "http://www.appness.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'HR',
    'version': '14.1.0',
    'sequence': 7,

    # any module necessary for this one to work correctly
    'depends': ['base','hr','hr_contract','hr_salary_increment','hr_employee_rotation','hr_wage_by_grade'],

    # always loaded
    'data': [
      'security/ir.model.access.csv',
      'views/employee_promotion.xml',
      'data/mail_data.xml',
      # 'report/report_views.xml',
      'report/employee_promotion_report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
   #     'demo.xml',
    ],
}