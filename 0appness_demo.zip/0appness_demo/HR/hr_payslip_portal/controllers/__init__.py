# -*- coding: utf-8 -*-

from . import payslip_portal
