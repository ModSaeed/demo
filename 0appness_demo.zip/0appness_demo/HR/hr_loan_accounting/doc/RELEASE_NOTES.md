## Module <hr_loan_accounting>

#### 06.09.2020
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Appness HR


