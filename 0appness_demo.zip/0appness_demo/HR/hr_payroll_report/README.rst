Payroll Report v13
==================
PDF and XLS Reports for payroll Module.


Features
========
* Payroll details Report XLS and PDF
* Payroll Variance Report Total XLS and PDF
* payroll bank Report PDF

Installation
============
To install this module, you need also the **report_xlsx**


Credits
=======
Appness Tech <www.appness.net>

Author
------
*  Developer v12 : appness Team
*  Developer v13 : appness Team
