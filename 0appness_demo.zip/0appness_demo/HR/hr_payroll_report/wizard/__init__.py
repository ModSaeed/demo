# -*- coding: utf-8 -*-
from . import payroll_report_wizard
from . import payroll_report_config
