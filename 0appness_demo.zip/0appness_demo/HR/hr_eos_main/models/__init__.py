# -*- coding: utf-8 -*-
from . import model
from . import hr_payslip
from . import hr_contract
from . import res_config_settings
from . import gratuity_configuration
