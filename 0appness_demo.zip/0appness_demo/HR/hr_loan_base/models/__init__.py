from . import hr_loan
from . import loan_config
from . import hr_loan_clear
from . import hr_loan_recalculation
from . import hr_payroll
# from . import res_config
